package com.s4me.assistant;

import android.content.Context;
import android.content.Intent;
import android.util.Base64;
import android.util.Log;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Mini server HTTP, stesso schema di Alfa Assistant.
 * Endpoint: /ping, /getSourceByPageFinished, /clearCookies, /quit
 * I valori di url, userAgent, headers e returnWhenCookieNameFound sono in base64.
 * Accetta solo connessioni dalla rete locale.
 */
public class HttpServer {
    private static final String TAG = "S4MeHttp";

    private final Context app;
    private final int port;
    private final Solver solver;
    private final ExecutorService pool = Executors.newCachedThreadPool();
    private ServerSocket server;
    private volatile boolean running = false;

    public HttpServer(Context ctx, int port) {
        this.app = ctx.getApplicationContext();
        this.port = port;
        this.solver = new Solver(app);
    }

    public synchronized void start() throws IOException {
        if (running) return;
        server = new ServerSocket();
        server.setReuseAddress(true);
        server.bind(new InetSocketAddress(port));
        running = true;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                acceptLoop();
            }
        }, "s4me-accept");
        t.setDaemon(true);
        t.start();
    }

    public synchronized void stop() {
        running = false;
        try {
            if (server != null) server.close();
        } catch (IOException ignored) {
        }
        pool.shutdownNow();
    }

    private void acceptLoop() {
        while (running) {
            try {
                final Socket s = server.accept();
                pool.execute(new Runnable() {
                    @Override
                    public void run() {
                        handle(s);
                    }
                });
            } catch (Exception e) {
                if (running) Log.e(TAG, "accept: " + e);
            }
        }
    }

    private void handle(Socket s) {
        try {
            s.setSoTimeout(15000);
            BufferedReader in = new BufferedReader(
                    new InputStreamReader(s.getInputStream(), "UTF-8"));
            String line = in.readLine();
            if (line == null) return;
            String h;
            while ((h = in.readLine()) != null && h.length() > 0) {
                // intestazioni ignorate
            }

            InetAddress ra = s.getInetAddress();
            if (!(ra.isLoopbackAddress() || ra.isSiteLocalAddress() || ra.isLinkLocalAddress())) {
                send(s, 403, "{\"error\":\"forbidden\"}");
                return;
            }

            String[] parts = line.split(" ");
            if (parts.length < 2) {
                send(s, 400, "{\"error\":\"bad request\"}");
                return;
            }
            String target = parts[1];
            String path = target;
            String query = "";
            int q = target.indexOf('?');
            if (q >= 0) {
                path = target.substring(0, q);
                query = target.substring(q + 1);
            }
            Map<String, String> p = parseQuery(query);

            if (path.equals("/ping")) {
                JSONObject o = new JSONObject();
                o.put("assistantVersion", AssistantService.VERSION);
                o.put("wvbVersion", WebHolder.webViewVersion());
                o.put("busy", solver.busy);
                send(s, 200, o.toString());
            } else if (path.equals("/getSourceByPageFinished")) {
                String url = b64(p, "url");
                if (url == null) {
                    send(s, 400, "{\"error\":\"url mancante\"}");
                    return;
                }
                long t = 30000;
                try {
                    t = Long.parseLong(p.get("time"));
                } catch (Exception ignored) {
                }
                if (t < 5000) t = 5000;
                if (t > 180000) t = 180000;

                String rc = b64(p, "returnWhenCookieNameFound");
                String cookieName = null;
                if (rc != null) {
                    int i = rc.lastIndexOf('|');
                    cookieName = i >= 0 ? rc.substring(i + 1) : rc;
                }
                boolean clear = "true".equalsIgnoreCase(p.get("removeAllCookies"));
                JSONObject r = solver.solve(url, t, b64(p, "userAgent"), cookieName,
                        b64(p, "headers"), clear);
                send(s, 200, r.toString());
            } else if (path.equals("/clearCookies")) {
                solver.clearCookies();
                send(s, 200, "{\"ok\":true}");
            } else if (path.equals("/quit")) {
                send(s, 200, "{\"ok\":true}");
                app.stopService(new Intent(app, AssistantService.class));
            } else {
                send(s, 404, "{\"error\":\"not found\"}");
            }
        } catch (Exception e) {
            Log.e(TAG, "handle: " + e);
        } finally {
            try {
                s.close();
            } catch (IOException ignored) {
            }
        }
    }

    private void send(Socket s, int code, String body) throws IOException {
        byte[] b = body.getBytes("UTF-8");
        String head = "HTTP/1.1 " + code + (code == 200 ? " OK" : " Error") + "\r\n"
                + "Content-Type: application/json; charset=utf-8\r\n"
                + "Content-Length: " + b.length + "\r\n"
                + "Connection: close\r\n\r\n";
        OutputStream o = s.getOutputStream();
        o.write(head.getBytes("UTF-8"));
        o.write(b);
        o.flush();
    }

    private static Map<String, String> parseQuery(String query) {
        Map<String, String> map = new HashMap<String, String>();
        if (query == null || query.length() == 0) return map;
        for (String kv : query.split("&")) {
            int i = kv.indexOf('=');
            if (i <= 0) continue;
            String k = kv.substring(0, i);
            String v = kv.substring(i + 1);
            try {
                v = URLDecoder.decode(v, "UTF-8");
            } catch (Exception ignored) {
            }
            map.put(k, v);
        }
        return map;
    }

    /** Decodifica un parametro base64. Il "+" arrivato come spazio viene ripristinato. */
    private static String b64(Map<String, String> p, String key) {
        String v = p.get(key);
        if (v == null || v.length() == 0) return null;
        try {
            return new String(Base64.decode(v.replace(' ', '+'), Base64.DEFAULT), "UTF-8");
        } catch (Exception e) {
            return null;
        }
    }
}

package com.s4me.assistant;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.StorageController;

import java.net.URI;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Stessa logica del Solver, ma con GeckoView. */
public class GeckoSolver {
    private static final Object LOCK = new Object();
    private final Context app;
    private final Handler main = new Handler(Looper.getMainLooper());
    public volatile boolean busy = false;
    /** Tempi dell'ultima risoluzione, letti da /ping. */
    public static volatile JSONObject lastSolve = null;

    public GeckoSolver(Context ctx) {
        this.app = ctx.getApplicationContext();
    }

    private void onMain(final Runnable r) {
        final CountDownLatch l = new CountDownLatch(1);
        main.post(new Runnable() {
            @Override
            public void run() {
                try {
                    r.run();
                } catch (Throwable t) {
                    android.util.Log.e("S4MeGecko", "main: " + t);
                } finally {
                    l.countDown();
                }
            }
        });
        try {
            l.await(15, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
        }
    }

    public void clearCookies() {
        onMain(new Runnable() {
            @Override
            public void run() {
                GeckoHolder.get(app);
                GeckoHolder.runtime().getStorageController().clearData(StorageController.ClearFlags.ALL);
            }
        });
    }

    public JSONObject solve(final String url, long timeoutMs, final String waitCookie,
                            final boolean clear) {
        synchronized (LOCK) {
            busy = true;
            JSONObject out = new JSONObject();
            try {
                final String origin = origin(url);
                GeckoHolder.wantHtml = false;
                final long startAt = System.currentTimeMillis();
                onMain(new Runnable() {
                    @Override
                    public void run() {
                        GeckoSession s = GeckoHolder.get(app);
                        if (clear) {
                            GeckoHolder.runtime().getStorageController()
                                    .clearData(StorageController.ClearFlags.ALL);
                        }
                        s.loadUri(url);
                    }
                });

                boolean needCookie = waitCookie != null && waitCookie.length() > 0;
                boolean solved = false;
                long firstSnapMs = -1;
                long solvedMs = -1;
                long end = startAt + timeoutMs;
                JSONObject last = null;
                while (System.currentTimeMillis() < end) {
                    Thread.sleep(600);
                    JSONObject sn = GeckoHolder.snap;
                    if (sn == null || GeckoHolder.snapAt < startAt + 1200) continue;
                    String href = sn.optString("href");
                    if (href.startsWith("about:")) continue;
                    last = sn;
                    if (firstSnapMs < 0) firstSnapMs = System.currentTimeMillis() - startAt;
                    boolean cookieOk = !needCookie || hasCookie(sn.optJSONArray("cookies"), waitCookie);
                    if (cookieOk && !Solver.isChallenge(sn.optString("title")) && !sn.optBoolean("chall")) {
                        solved = true;
                        solvedMs = System.currentTimeMillis() - startAt;
                        break;
                    }
                }

                String html = "";
                if (last != null) {
                    GeckoHolder.wantHtml = true;
                    long until = System.currentTimeMillis() + 5000;
                    long mark = GeckoHolder.snapAt;
                    while (System.currentTimeMillis() < until) {
                        Thread.sleep(400);
                        JSONObject sn = GeckoHolder.snap;
                        if (sn != null && GeckoHolder.snapAt > mark && !sn.isNull("html")) {
                            last = sn;
                            html = sn.optString("html");
                            break;
                        }
                    }
                    GeckoHolder.wantHtml = false;
                }

                String finalUrl = last != null ? last.optString("href") : url;
                String title = last != null ? last.optString("title") : "";
                JSONArray cks = last != null && last.optJSONArray("cookies") != null
                        ? last.optJSONArray("cookies") : new JSONArray();
                StringBuilder ck = new StringBuilder();
                JSONArray arr = new JSONArray();
                for (int i = 0; i < cks.length(); i++) {
                    JSONObject c = cks.getJSONObject(i);
                    if (ck.length() > 0) ck.append("; ");
                    ck.append(c.optString("name")).append("=").append(c.optString("value"));
                    arr.put(new JSONObject().put("name", c.optString("name"))
                            .put("value", c.optString("value")));
                }

                out.put("assistantVersion", AssistantService.VERSION);
                out.put("wvbVersion", "gecko " + GeckoHolder.version());
                out.put("userAgent", GeckoHolder.geckoUa);
                out.put("url", finalUrl);
                out.put("title", title);
                out.put("solved", solved);
                out.put("blocked", !solved && Solver.isChallenge(title));
                out.put("cookiesList", ck.toString());
                out.put("cookies", arr);
                JSONArray src = new JSONArray();
                src.put(new JSONObject().put("url", finalUrl).put("source", html));
                out.put("htmlSources", src);
                out.put("urls", new JSONArray().put(finalUrl));
                out.put("engine", "gecko");
                JSONObject tm = new JSONObject();
                tm.put("url", origin);
                tm.put("firstPageMs", firstSnapMs);
                tm.put("solvedMs", solvedMs);
                tm.put("totalMs", System.currentTimeMillis() - startAt);
                tm.put("timedOut", !solved);
                tm.put("limitMs", timeoutMs);
                tm.put("geckoReadyMs", GeckoHolder.readyAt > 0 ? GeckoHolder.readyAt - GeckoHolder.createdAt : -1);
                lastSolve = tm;
                out.put("timing", tm);
            } catch (Exception e) {
                try {
                    out.put("error", String.valueOf(e));
                } catch (Exception ignored) {
                }
            } finally {
                busy = false;
            }
            return out;
        }
    }

    private static boolean hasCookie(JSONArray a, String name) {
        if (a == null) return false;
        for (int i = 0; i < a.length(); i++) {
            JSONObject c = a.optJSONObject(i);
            if (c != null && name.equals(c.optString("name"))) return true;
        }
        return false;
    }

    private static String origin(String url) {
        try {
            URI u = URI.create(url);
            return u.getScheme() + "://" + u.getHost();
        } catch (Exception e) {
            return url;
        }
    }
}

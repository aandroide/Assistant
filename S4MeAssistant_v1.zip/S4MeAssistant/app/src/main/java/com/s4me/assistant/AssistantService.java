package com.s4me.assistant;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.util.Log;

import java.io.IOException;

/** Servizio in primo piano che tiene acceso il server HTTP. */
public class AssistantService extends Service {
    public static final String VERSION = "1.0.0";
    public static final int PORT = 8787;
    public static volatile boolean running = false;

    private HttpServer http;
    private PowerManager.WakeLock wake;
    private WifiManager.WifiLock wifi;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (http == null) {
            startForeground(1, buildNotification());
            try {
                http = new HttpServer(this, PORT);
                http.start();
                running = true;
            } catch (IOException e) {
                Log.e("S4MeService", "avvio server: " + e);
                http = null;
                stopSelf();
                return START_NOT_STICKY;
            }
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "s4me:server");
            wake.acquire();
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "s4me:wifi");
            wifi.acquire();
        }
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        if (http != null) http.stop();
        http = null;
        if (wake != null && wake.isHeld()) wake.release();
        if (wifi != null && wifi.isHeld()) wifi.release();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private Notification buildNotification() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(
                    "s4me", "S4Me Assistant", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE))
                    .createNotificationChannel(ch);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, "s4me")
                : new Notification.Builder(this);
        PendingIntent pi = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE);
        b.setContentTitle("S4Me Assistant attivo")
                .setContentText("Porta " + PORT)
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setContentIntent(pi)
                .setOngoing(true);
        return b.build();
    }
}

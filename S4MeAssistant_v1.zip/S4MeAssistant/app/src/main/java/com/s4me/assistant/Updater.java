package com.s4me.assistant;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import androidx.core.content.FileProvider;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.HashSet;
import java.util.Set;

/**
 * Aggiornamento automatico dalla release GitHub. La release contiene update.json con versione,
 * dimensione e SHA-256 dell'APK. Prima di installare si controllano dimensione, SHA-256,
 * nome del pacchetto, versione e certificato di firma.
 */
public class Updater {
    public static final String REPO = "aandroide/Assistant";
    /** Tag della release da controllare. Nella versione definitiva e "latest". */
    public static final String TAG = "prova-update";
    private static final long CHECK_INTERVAL = 30 * 60 * 1000L;

    public static class Info {
        public String versionName;
        public int versionCode;
        public int minSdk;
        public String apkName;
        public String apkUrl;
        public long size;
        public String sha256;
    }

    public interface Progress {
        void percent(int p);
    }

    public static class UpdateException extends Exception {
        public UpdateException(String m) {
            super(m);
        }
    }

    // ---------- versione installata ----------

    @SuppressWarnings("deprecation")
    public static int installedCode(Context c) {
        try {
            PackageInfo pi = c.getPackageManager().getPackageInfo(c.getPackageName(), 0);
            return Build.VERSION.SDK_INT >= 28 ? (int) pi.getLongVersionCode() : pi.versionCode;
        } catch (Exception e) {
            return 0;
        }
    }

    @SuppressWarnings("deprecation")
    public static String installedName(Context c) {
        try {
            return c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "";
        }
    }

    // ---------- controllo ----------

    public static boolean checkDue(Context c) {
        SharedPreferences sp = c.getSharedPreferences("s4me", Context.MODE_PRIVATE);
        long last = sp.getLong("update_checked", 0);
        long now = System.currentTimeMillis();
        return now < last || now - last > CHECK_INTERVAL;
    }

    /** Ritorna le informazioni sulla nuova versione, oppure null se non ce ne sono. */
    public static Info check(Context c) throws Exception {
        String api = "https://api.github.com/repos/" + REPO + "/releases/tags/" + TAG;
        JSONObject rel = new JSONObject(text(api, 1024 * 1024, "application/vnd.github+json"));
        c.getSharedPreferences("s4me", Context.MODE_PRIVATE).edit()
                .putLong("update_checked", System.currentTimeMillis()).apply();
        JSONArray assets = rel.getJSONArray("assets");
        String manifestUrl = assetUrl(assets, "update.json");
        if (manifestUrl == null) return null;
        JSONObject m = new JSONObject(text(manifestUrl, 64 * 1024, "application/octet-stream"));
        if (!"com.s4me.assistant".equals(m.optString("applicationId"))) return null;
        JSONObject apks = m.getJSONObject("apks");
        JSONObject chosen = null;
        for (String abi : Build.SUPPORTED_ABIS) {
            if (apks.has(abi)) {
                chosen = apks.getJSONObject(abi);
                break;
            }
        }
        if (chosen == null && apks.has("universal")) chosen = apks.getJSONObject("universal");
        if (chosen == null) return null;

        Info i = new Info();
        i.versionName = m.getString("versionName");
        i.versionCode = m.getInt("versionCode");
        i.minSdk = m.optInt("minSdk", 21);
        i.apkName = chosen.getString("name");
        i.size = chosen.getLong("size");
        i.sha256 = chosen.getString("sha256").toLowerCase();
        i.apkUrl = assetUrl(assets, i.apkName);
        if (i.apkUrl == null) return null;
        if (i.size <= 0 || i.size > 400L * 1024 * 1024) throw new UpdateException("Dimensione non valida");
        if (i.versionCode <= installedCode(c) || i.minSdk > Build.VERSION.SDK_INT) return null;
        return i;
    }

    private static String assetUrl(JSONArray assets, String name) throws Exception {
        String prefix = "https://github.com/" + REPO + "/releases/download/" + TAG + "/";
        for (int k = 0; k < assets.length(); k++) {
            JSONObject a = assets.getJSONObject(k);
            if (name.equals(a.optString("name")) && "uploaded".equals(a.optString("state"))) {
                String u = a.getString("browser_download_url");
                if (!u.equals(prefix + name)) throw new UpdateException("Indirizzo non valido");
                return u;
            }
        }
        return null;
    }

    private static HttpURLConnection open(String url, String accept) throws Exception {
        if (!url.startsWith("https://")) throw new UpdateException("Serve HTTPS");
        HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
        h.setConnectTimeout(10000);
        h.setReadTimeout(30000);
        h.setRequestProperty("User-Agent", "S4MeAssistant/" + AssistantService.VERSION);
        h.setRequestProperty("Accept", accept);
        return h;
    }

    private static String text(String url, int limit, String accept) throws Exception {
        HttpURLConnection h = open(url, accept);
        try {
            if (h.getResponseCode() != 200) throw new UpdateException("Risposta " + h.getResponseCode());
            InputStream in = h.getInputStream();
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            byte[] b = new byte[8192];
            int n;
            while ((n = in.read(b)) > 0) {
                if (o.size() + n > limit) throw new UpdateException("Risposta troppo grande");
                o.write(b, 0, n);
            }
            return o.toString("UTF-8");
        } finally {
            h.disconnect();
        }
    }

    // ---------- download e verifica ----------

    public static File download(Context c, Info info, Progress progress) throws Exception {
        File dir = new File(c.getCacheDir(), "updates");
        dir.mkdirs();
        File[] old = dir.listFiles();
        if (old != null) for (File f : old) f.delete();
        File out = new File(dir, "update.apk");
        HttpURLConnection h = open(info.apkUrl, "application/octet-stream");
        h.setReadTimeout(60000);
        try {
            if (h.getResponseCode() != 200) throw new UpdateException("Download non riuscito: " + h.getResponseCode());
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            InputStream in = h.getInputStream();
            FileOutputStream fo = new FileOutputStream(out);
            byte[] b = new byte[32 * 1024];
            long copied = 0;
            int last = -1, n;
            try {
                while ((n = in.read(b)) > 0) {
                    copied += n;
                    if (copied > info.size) throw new UpdateException("File piu grande del previsto");
                    md.update(b, 0, n);
                    fo.write(b, 0, n);
                    int p = (int) (copied * 100 / info.size);
                    if (p != last) {
                        last = p;
                        if (progress != null) progress.percent(p);
                    }
                }
            } finally {
                fo.close();
            }
            if (copied != info.size) throw new UpdateException("Download incompleto");
            if (!hex(md.digest()).equals(info.sha256)) {
                out.delete();
                throw new UpdateException("Il file scaricato non supera la verifica");
            }
        } finally {
            h.disconnect();
        }
        verifyApk(c, out, info);
        return out;
    }

    private static String hex(byte[] d) {
        StringBuilder sb = new StringBuilder();
        for (byte x : d) sb.append(String.format("%02x", x));
        return sb.toString();
    }

    @SuppressWarnings("deprecation")
    private static Set<String> certs(PackageInfo pi) throws Exception {
        Signature[] sigs;
        if (Build.VERSION.SDK_INT >= 28) {
            sigs = pi.signingInfo != null ? pi.signingInfo.getApkContentsSigners() : null;
        } else {
            sigs = pi.signatures;
        }
        Set<String> out = new HashSet<String>();
        if (sigs != null) {
            for (Signature s : sigs) {
                out.add(hex(MessageDigest.getInstance("SHA-256").digest(s.toByteArray())));
            }
        }
        return out;
    }

    @SuppressWarnings("deprecation")
    private static void verifyApk(Context c, File apk, Info info) throws Exception {
        PackageManager pm = c.getPackageManager();
        int flags = Build.VERSION.SDK_INT >= 28
                ? PackageManager.GET_SIGNING_CERTIFICATES | PackageManager.GET_SIGNATURES
                : PackageManager.GET_SIGNATURES;
        PackageInfo mine = pm.getPackageInfo(c.getPackageName(), flags);
        PackageInfo arc = pm.getPackageArchiveInfo(apk.getAbsolutePath(), flags);
        if (arc == null) throw new UpdateException("APK non leggibile");
        if (!c.getPackageName().equals(arc.packageName)) throw new UpdateException("Pacchetto diverso");
        int code = Build.VERSION.SDK_INT >= 28 ? (int) arc.getLongVersionCode() : arc.versionCode;
        if (code != info.versionCode || code <= installedCode(c)) throw new UpdateException("Versione non coerente");
        Set<String> a = certs(mine);
        Set<String> b = certs(arc);
        if (a.isEmpty() || !a.equals(b)) {
            throw new UpdateException("Firma diversa: disinstalla l'app attuale e installa questa versione una volta");
        }
    }

    // ---------- installazione ----------

    /** Ritorna false se manca il permesso: in quel caso apre la schermata per concederlo. */
    public static boolean install(Activity a, File apk) {
        if (Build.VERSION.SDK_INT >= 26 && !a.getPackageManager().canRequestPackageInstalls()) {
            Intent s = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + a.getPackageName()));
            a.startActivity(s);
            return false;
        }
        Uri uri = FileProvider.getUriForFile(a, a.getPackageName() + ".updates", apk);
        Intent i = new Intent(Intent.ACTION_INSTALL_PACKAGE);
        i.setData(uri);
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        a.startActivity(i);
        return true;
    }
}

package com.s4me.assistant;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.view.ViewGroup;

import org.json.JSONObject;
import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoRuntimeSettings;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoSessionSettings;
import org.mozilla.geckoview.GeckoView;
import org.mozilla.geckoview.WebExtension;

import java.io.File;
import java.io.FileWriter;

/**
 * Motore alternativo basato su GeckoView (Firefox). Serve sui dispositivi con la WebView di sistema
 * troppo vecchia (per esempio Fire Stick HD, Chromium 108). Un'estensione interna legge titolo,
 * cookie e HTML della pagina e li passa all'app.
 */
public class GeckoHolder {
    private static final String TAG = "S4MeGecko";

    /** Sotto questa versione maggiore della WebView si usa Gecko. */
    public static final int MIN_WEBVIEW = 110;

    private static GeckoRuntime runtime;
    private static GeckoSession session;
    private static GeckoView view;
    private static boolean installed = false;

    public static volatile JSONObject snap = null;
    public static volatile long snapAt = 0;
    public static volatile boolean wantHtml = false;
    public static volatile String geckoUa = "";
    public static volatile long createdAt = 0;
    public static volatile long readyAt = 0;

    public static int webViewMajor() {
        String v = WebHolder.webViewVersion();
        try {
            int i = 0;
            while (i < v.length() && Character.isDigit(v.charAt(i))) i++;
            return i > 0 ? Integer.parseInt(v.substring(0, i)) : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    public static boolean autoUse() {
        int m = webViewMajor();
        return m > 0 && m < MIN_WEBVIEW;
    }

    private static void writeConfig(Context ctx) {
        try {
            StringBuilder sb = new StringBuilder("prefs:\n");
            sb.append("  network.dns.disableIPv6: true\n");
            // Alleggerimento: meno rete e meno processi all'avvio su dispositivi con poca memoria
            sb.append("  toolkit.telemetry.enabled: false\n");
            sb.append("  datareporting.healthreport.uploadEnabled: false\n");
            sb.append("  browser.safebrowsing.malware.enabled: false\n");
            sb.append("  browser.safebrowsing.phishing.enabled: false\n");
            sb.append("  browser.safebrowsing.downloads.enabled: false\n");
            sb.append("  network.http.speculative-parallel-limit: 0\n");
            sb.append("  network.prefetch-next: false\n");
            sb.append("  media.autoplay.default: 5\n");
            sb.append("  dom.ipc.processCount: 1\n");
            if (Ipv4Proxy.start()) {
                int p = Ipv4Proxy.port();
                sb.append("  network.proxy.type: 1\n");
                sb.append("  network.proxy.http: \"127.0.0.1\"\n");
                sb.append("  network.proxy.http_port: ").append(p).append("\n");
                sb.append("  network.proxy.ssl: \"127.0.0.1\"\n");
                sb.append("  network.proxy.ssl_port: ").append(p).append("\n");
                sb.append("  network.proxy.allow_hijacking_localhost: true\n");
                sb.append("  network.proxy.no_proxies_on: \"\"\n");
            }
            File f = new File(ctx.getFilesDir(), "geckoview-config.yaml");
            FileWriter w = new FileWriter(f);
            w.write(sb.toString());
            w.close();
        } catch (Exception e) {
            Log.e(TAG, "config: " + e);
        }
    }

    /** Da chiamare dal thread principale. */
    public static synchronized GeckoSession get(Context ctx) {
        if (session != null) return session;
        Context app = ctx.getApplicationContext();
        writeConfig(app);
        GeckoRuntimeSettings rs = new GeckoRuntimeSettings.Builder()
                .configFilePath(new File(app.getFilesDir(), "geckoview-config.yaml").getAbsolutePath())
                .build();
        createdAt = System.currentTimeMillis();
        runtime = GeckoRuntime.create(app, rs);

        GeckoSessionSettings ss = new GeckoSessionSettings.Builder()
                .userAgentMode(GeckoSessionSettings.USER_AGENT_MODE_DESKTOP)
                .viewportMode(GeckoSessionSettings.VIEWPORT_MODE_DESKTOP)
                .build();
        session = new GeckoSession(ss);
        session.open(runtime);

        if (!installed) {
            installed = true;
            runtime.getWebExtensionController()
                    .installBuiltIn("resource://android/assets/messaging/")
                    .then(new GeckoResult.OnValueListener<WebExtension, Void>() {
                        @Override
                        public GeckoResult<Void> onValue(WebExtension ext) {
                            readyAt = System.currentTimeMillis();
                            ext.setMessageDelegate(new WebExtension.MessageDelegate() {
                                @Override
                                public GeckoResult<Object> onMessage(String nativeApp, Object message,
                                                                     WebExtension.MessageSender sender) {
                                    try {
                                        JSONObject o = message instanceof JSONObject
                                                ? (JSONObject) message : new JSONObject(String.valueOf(message));
                                        snap = o;
                                        snapAt = System.currentTimeMillis();
                                        String ua = o.optString("ua");
                                        if (ua.length() > 0) geckoUa = ua;
                                        JSONObject r = new JSONObject();
                                        r.put("wantHtml", wantHtml);
                                        return GeckoResult.<Object>fromValue(r);
                                    } catch (Exception e) {
                                        Log.e(TAG, "messaggio: " + e);
                                        return GeckoResult.<Object>fromValue(null);
                                    }
                                }
                            }, "browser");
                            return null;
                        }
                    }, new GeckoResult.OnExceptionListener<Void>() {
                        @Override
                        public GeckoResult<Void> onException(Throwable t) {
                            Log.e(TAG, "estensione: " + t);
                            return null;
                        }
                    });
        }
        return session;
    }

    public static synchronized void attach(Activity activity, ViewGroup container) {
        GeckoSession s = get(activity);
        detach();
        view = new GeckoView(activity);
        view.setSession(s);
        container.addView(view, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    public static synchronized void detach() {
        if (view == null) return;
        try {
            view.releaseSession();
        } catch (Exception ignored) {
        }
        if (view.getParent() instanceof ViewGroup) {
            ((ViewGroup) view.getParent()).removeView(view);
        }
        view = null;
    }

    public static synchronized GeckoRuntime runtime() {
        return runtime;
    }

    public static String version() {
        return "";
    }
}

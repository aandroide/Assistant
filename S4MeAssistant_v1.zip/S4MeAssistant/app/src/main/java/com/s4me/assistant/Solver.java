package com.s4me.assistant;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.webkit.CookieManager;
import android.webkit.ValueCallback;
import android.webkit.WebSettings;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.net.URI;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/** Carica una pagina nella WebView e attende che la challenge sia superata. */
public class Solver {
    private static final Object LOCK = new Object();

    private final Context app;
    private final Handler main = new Handler(Looper.getMainLooper());
    public volatile boolean busy = false;

    public Solver(Context ctx) {
        this.app = ctx.getApplicationContext();
    }

    // ---------- utilita thread ----------

    private void onMain(final Runnable r) {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            r.run();
            return;
        }
        final CountDownLatch l = new CountDownLatch(1);
        main.post(new Runnable() {
            @Override
            public void run() {
                try {
                    r.run();
                } finally {
                    l.countDown();
                }
            }
        });
        try {
            l.await(10, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
        }
    }

    /** Esegue JavaScript nella pagina. Da chiamare solo da thread non principali. */
    private String js(final String code) {
        final String[] res = new String[1];
        final CountDownLatch l = new CountDownLatch(1);
        main.post(new Runnable() {
            @Override
            public void run() {
                WebHolder.get(app).evaluateJavascript(code, new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String v) {
                        res[0] = v;
                        l.countDown();
                    }
                });
            }
        });
        try {
            l.await(8, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
        }
        return decode(res[0]);
    }

    private static String decode(String v) {
        if (v == null || v.equals("null")) return "";
        try {
            Object o = new JSONTokener(v).nextValue();
            return o instanceof String ? (String) o : String.valueOf(o);
        } catch (Exception e) {
            return v;
        }
    }

    private String cookies(final String origin) {
        final String[] res = new String[1];
        onMain(new Runnable() {
            @Override
            public void run() {
                res[0] = CookieManager.getInstance().getCookie(origin);
            }
        });
        return res[0] == null ? "" : res[0];
    }

    public void clearCookies() {
        onMain(new Runnable() {
            @Override
            public void run() {
                CookieManager cm = CookieManager.getInstance();
                cm.removeAllCookies(null);
                cm.flush();
                WebHolder.get(app).clearCache(true);
            }
        });
    }

    // ---------- logica principale ----------

    public JSONObject solve(final String url, long timeoutMs, final String userAgent,
                            final String waitCookie, final String headersJson,
                            final boolean clear) {
        synchronized (LOCK) {
            busy = true;
            JSONObject out = new JSONObject();
            try {
                final String origin = origin(url);
                final int[] before = new int[1];

                onMain(new Runnable() {
                    @Override
                    public void run() {
                        WebView w = WebHolder.get(app);
                        WebSettings st = w.getSettings();
                        st.setUserAgentString(userAgent != null && userAgent.length() > 0
                                ? userAgent : WebHolder.defaultUserAgent);
                        if (clear) {
                            CookieManager cm = CookieManager.getInstance();
                            cm.removeAllCookies(null);
                            cm.flush();
                            w.clearCache(true);
                        }
                        before[0] = WebHolder.finishedCount;
                        Map<String, String> h = headers(headersJson);
                        if (h.isEmpty()) w.loadUrl(url);
                        else w.loadUrl(url, h);
                    }
                });

                long end = System.currentTimeMillis() + timeoutMs;
                boolean solved = false;
                String title = "";
                boolean needCookie = waitCookie != null && waitCookie.length() > 0;

                while (System.currentTimeMillis() < end) {
                    Thread.sleep(600);
                    if (WebHolder.finishedCount <= before[0]) continue;
                    String ck = cookies(origin);
                    boolean cookieOk = !needCookie || hasCookie(ck, waitCookie);
                    title = js("document.title");
                    if (cookieOk && !isChallenge(title)) {
                        solved = true;
                        break;
                    }
                }

                String html = js("document.documentElement.outerHTML");
                String finalUrl = js("location.href");
                if (finalUrl.length() == 0) finalUrl = url;
                title = js("document.title");

                String ck = cookies(origin);
                String finalOrigin = origin(finalUrl);
                if (!finalOrigin.equals(origin)) {
                    String ck2 = cookies(finalOrigin);
                    if (ck2.length() > 0) ck = ck.length() > 0 ? ck + "; " + ck2 : ck2;
                }

                final String[] ua = new String[1];
                onMain(new Runnable() {
                    @Override
                    public void run() {
                        ua[0] = WebHolder.get(app).getSettings().getUserAgentString();
                    }
                });

                out.put("assistantVersion", AssistantService.VERSION);
                out.put("wvbVersion", WebHolder.webViewVersion());
                out.put("userAgent", ua[0]);
                out.put("url", finalUrl);
                out.put("title", title);
                out.put("solved", solved);
                out.put("blocked", !solved && isChallenge(title));
                out.put("cookiesList", ck);
                out.put("cookies", cookiesToArray(ck));
                JSONArray src = new JSONArray();
                src.put(new JSONObject().put("url", finalUrl).put("source", html));
                out.put("htmlSources", src);
                out.put("urls", new JSONArray().put(finalUrl));
            } catch (Exception e) {
                try {
                    out.put("error", String.valueOf(e));
                } catch (Exception ignored) {
                }
            } finally {
                busy = false;
            }
            return out;
        }
    }

    // ---------- helper ----------

    private static boolean isChallenge(String title) {
        if (title == null) return true;
        String t = title.trim().toLowerCase();
        if (t.length() == 0) return true;
        return t.contains("just a moment")
                || t.contains("un momento")
                || t.contains("un attimo")
                || t.contains("attention required")
                || t.contains("checking your browser")
                || t.contains("cloudflare");
    }

    private static boolean hasCookie(String ck, String name) {
        if (ck == null) return false;
        for (String part : ck.split(";")) {
            if (part.trim().startsWith(name + "=")) return true;
        }
        return false;
    }

    private static JSONArray cookiesToArray(String ck) throws Exception {
        JSONArray arr = new JSONArray();
        for (String part : ck.split(";")) {
            int i = part.indexOf('=');
            if (i <= 0) continue;
            arr.put(new JSONObject()
                    .put("name", part.substring(0, i).trim())
                    .put("value", part.substring(i + 1).trim()));
        }
        return arr;
    }

    private static String origin(String url) {
        try {
            URI u = URI.create(url);
            String o = u.getScheme() + "://" + u.getHost();
            if (u.getPort() > 0) o += ":" + u.getPort();
            return o;
        } catch (Exception e) {
            return url;
        }
    }

    /** Accetta il formato di Alfa: [{"name":"x","value":"y"}] oppure {"x":"y"}. */
    private static Map<String, String> headers(String json) {
        Map<String, String> map = new HashMap<String, String>();
        if (json == null || json.length() == 0) return map;
        try {
            Object o = new JSONTokener(json).nextValue();
            if (o instanceof JSONArray) {
                JSONArray a = (JSONArray) o;
                for (int i = 0; i < a.length(); i++) {
                    JSONObject h = a.getJSONObject(i);
                    put(map, h.optString("name"), h.optString("value"));
                }
            } else if (o instanceof JSONObject) {
                JSONObject h = (JSONObject) o;
                Iterator<String> it = h.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    put(map, k, h.optString(k));
                }
            }
        } catch (Exception ignored) {
        }
        return map;
    }

    private static void put(Map<String, String> map, String k, String v) {
        if (k == null || k.length() == 0) return;
        if (k.equalsIgnoreCase("user-agent")) return;
        map.put(k, v);
    }
}

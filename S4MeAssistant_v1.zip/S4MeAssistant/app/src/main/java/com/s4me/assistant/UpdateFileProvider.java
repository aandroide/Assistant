package com.s4me.assistant;

import androidx.core.content.FileProvider;

public class UpdateFileProvider extends FileProvider {
}

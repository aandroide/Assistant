package com.s4me.assistant;

import android.app.Activity;
import android.content.Context;
import android.content.MutableContextWrapper;
import android.content.pm.PackageInfo;
import android.graphics.Bitmap;
import android.os.Build;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

/**
 * Tiene una sola WebView per tutta l'app. Quando l'Activity e' visibile la
 * WebView viene agganciata allo schermo, cosi la challenge Cloudflare e'
 * visibile e si puo toccare (Turnstile). Quando l'Activity e' chiusa la
 * WebView resta viva ma staccata.
 */
public class WebHolder {
    private static WebView webView;
    private static MutableContextWrapper wrapper;

    public static volatile int finishedCount = 0;
    public static volatile String currentUrl = "";
    public static volatile String defaultUserAgent = "";

    public static synchronized WebView get(Context ctx) {
        if (webView == null) {
            wrapper = new MutableContextWrapper(ctx.getApplicationContext());
            webView = new WebView(wrapper);

            WebSettings s = webView.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setLoadsImagesAutomatically(true);
            s.setJavaScriptCanOpenWindowsAutomatically(false);
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
            s.setMediaPlaybackRequiresUserGesture(true);
            defaultUserAgent = s.getUserAgentString();

            CookieManager cm = CookieManager.getInstance();
            cm.setAcceptCookie(true);
            cm.setAcceptThirdPartyCookies(webView, true);

            webView.setWebViewClient(new WebViewClient() {
                @Override
                public void onPageStarted(WebView v, String url, Bitmap favicon) {
                    currentUrl = url;
                }

                @Override
                public void onPageFinished(WebView v, String url) {
                    currentUrl = url;
                    finishedCount = finishedCount + 1;
                }
            });
            webView.onResume();
        }
        return webView;
    }

    public static synchronized void attach(Activity activity, ViewGroup container) {
        get(activity);
        wrapper.setBaseContext(activity);
        detachFromParent();
        container.addView(webView, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
    }

    public static synchronized void detach(Context app) {
        if (webView == null) return;
        detachFromParent();
        wrapper.setBaseContext(app.getApplicationContext());
    }

    private static void detachFromParent() {
        if (webView != null && webView.getParent() instanceof ViewGroup) {
            ((ViewGroup) webView.getParent()).removeView(webView);
        }
    }

    public static String webViewVersion() {
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                PackageInfo pi = WebView.getCurrentWebViewPackage();
                if (pi != null && pi.versionName != null) return pi.versionName;
            }
        } catch (Throwable ignored) {
        }
        return "";
    }
}

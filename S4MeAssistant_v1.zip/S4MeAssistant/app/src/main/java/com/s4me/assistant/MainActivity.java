package com.s4me.assistant;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.content.SharedPreferences;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;

public class MainActivity extends Activity {
    private TextView status;
    private FrameLayout container;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        int pad = (int) (8 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        status = new TextView(this);
        status.setTextSize(15);
        root.addView(status);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(button("START", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startServer();
                refreshLater();
            }
        }));
        row.addView(button("STOP", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopService(new Intent(MainActivity.this, AssistantService.class));
                refreshLater();
            }
        }));
        row.addView(button("BATTERIA", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askBatteryExemption();
            }
        }));
        row.addView(button("AVVIO AUTO", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openVendorSettings();
            }
        }));
        root.addView(row);

        container = new FrameLayout(this);
        root.addView(container, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
        startServer();

        // Alla prima apertura chiede l'esenzione dal risparmio energetico, una sola volta
        SharedPreferences sp = getSharedPreferences("s4me", MODE_PRIVATE);
        if (!batteryUnrestricted() && !sp.getBoolean("battery_asked", false)) {
            sp.edit().putBoolean("battery_asked", true).apply();
            askBatteryExemption();
        }
    }

    private boolean batteryUnrestricted() {
        if (Build.VERSION.SDK_INT < 23) return true;
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            return pm.isIgnoringBatteryOptimizations(getPackageName());
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        WebHolder.attach(this, container);
        refresh();
    }

    @Override
    protected void onPause() {
        WebHolder.detach(this);
        super.onPause();
    }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setOnClickListener(l);
        b.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        return b;
    }

    private void startServer() {
        Intent svc = new Intent(this, AssistantService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc);
        else startService(svc);
    }

    private void askBatteryExemption() {
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            }
        }
    }

    /**
     * Apre la schermata del produttore per l'avvio automatico e l'uso in background.
     * Le schermate non sono documentate e cambiano da modello a modello: si prova
     * l'elenco noto e, se nessuna si apre, si usa la pagina informazioni dell'app.
     */
    private void openVendorSettings() {
        String[][] known = {
                {"com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"},
                {"com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"},
                {"com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity"},
                {"com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"},
                {"com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity"},
                {"com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"},
                {"com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity"},
                {"com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity"},
                {"com.asus.mobilemanager", "com.asus.mobilemanager.powersaver.PowerSaverSettings"},
                {"com.letv.android.letvsafe", "com.letv.android.letvsafe.AutobootManageActivity"}
        };
        for (String[] k : known) {
            try {
                Intent i = new Intent();
                i.setComponent(new ComponentName(k[0], k[1]));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                return;
            } catch (Exception ignored) {
                // schermata non presente su questo telefono, si prova la successiva
            }
        }
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception ignored) {
        }
    }

    private void refreshLater() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                refresh();
            }
        }, 700);
    }

    private void refresh() {
        String ip = localIp();
        status.setText("Server: " + (AssistantService.running ? "ATTIVO" : "FERMO")
                + "\nIndirizzo: http://" + (ip.length() > 0 ? ip : "IP non trovato")
                + ":" + AssistantService.PORT
                + "\nWebView: " + WebHolder.webViewVersion()
                + "\nBatteria: " + (batteryUnrestricted() ? "senza restrizioni"
                : "LIMITATA, premi BATTERIA e consenti")
                + "\nTieni questa schermata aperta durante l'uso.");
    }

    private static String localIp() {
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (!a.isLoopbackAddress() && a instanceof Inet4Address
                            && a.isSiteLocalAddress()) {
                        return a.getHostAddress();
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return "";
    }
}

package com.s4me.assistant;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.content.SharedPreferences;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.util.Collections;

public class MainActivity extends Activity {
    private TextView status;
    private volatile String updateLine = "";
    private volatile boolean updateBusy = false;
    private Updater.Info pendingInfo;
    private File pendingApk;
    private Updater.Info waitingPermission;
    private int promptedCode = 0;
    private static final long UPDATE_EVERY = 30 * 60 * 1000L;
    private final Runnable updateTick = new Runnable() {
        @Override
        public void run() {
            if (!updateBusy && pendingApk == null && waitingPermission == null) checkUpdate(false);
            handler.postDelayed(this, UPDATE_EVERY);
        }
    };
    private FrameLayout container;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        int pad = (int) (8 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        status = new TextView(this);
        status.setTextSize(15);
        root.addView(status);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.addView(button("START", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startServer();
                refreshLater();
            }
        }));
        row.addView(button("STOP", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopService(new Intent(MainActivity.this, AssistantService.class));
                refreshLater();
            }
        }));
        row.addView(button("BATTERIA", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askBatteryExemption();
            }
        }));
        row.addView(button("AGGIORNA", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pendingApk != null) {
                    installPending();
                } else {
                    checkUpdate(true);
                }
            }
        }));
        root.addView(row);

        container = new FrameLayout(this);
        root.addView(container, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 1);
        }
        startServer();
        checkUpdate(false);

        // Alla prima apertura chiede l'esenzione dal risparmio energetico, una sola volta
        SharedPreferences sp = getSharedPreferences("s4me", MODE_PRIVATE);
        if (!batteryUnrestricted() && !sp.getBoolean("battery_asked", false)) {
            sp.edit().putBoolean("battery_asked", true).apply();
            askBatteryExemption();
        }
    }

    private boolean batteryUnrestricted() {
        if (Build.VERSION.SDK_INT < 23) return true;
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            return pm.isIgnoringBatteryOptimizations(getPackageName());
        } catch (Exception e) {
            return false;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        WebHolder.attach(this, container);
        refresh();
        handler.removeCallbacks(updateTick);
        handler.postDelayed(updateTick, UPDATE_EVERY);
        if (waitingPermission != null && !updateBusy
                && (Build.VERSION.SDK_INT < 26 || getPackageManager().canRequestPackageInstalls())) {
            Updater.Info w = waitingPermission;
            waitingPermission = null;
            downloadAndInstall(w);
        }
        if (pendingApk != null && Build.VERSION.SDK_INT >= 26 && getPackageManager().canRequestPackageInstalls()) {
            installPending();
        }
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(updateTick);
        WebHolder.detach(this);
        super.onPause();
    }

    private Button button(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setOnClickListener(l);
        b.setLayoutParams(new LinearLayout.LayoutParams(0,
                LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        return b;
    }

    private void startServer() {
        Intent svc = new Intent(this, AssistantService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc);
        else startService(svc);
    }

    private void askBatteryExemption() {
        if (batteryUnrestricted()) {
            Toast.makeText(this, "I permessi batteria sono gia abilitati: nessuna azione necessaria",
                    Toast.LENGTH_LONG).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= 23) {
            try {
                startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            }
        }
    }

    private void checkUpdate(final boolean manual) {
        if (updateBusy) return;
        updateBusy = true;
        updateLine = "Aggiornamenti: controllo in corso";
        refresh();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final Updater.Info info = Updater.check(MainActivity.this);
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            updateBusy = false;
                            if (info == null) {
                                updateLine = "Aggiornamenti: sei alla versione piu recente";
                                refresh();
                            } else {
                                updateLine = "Aggiornamenti: disponibile la " + info.versionName;
                                refresh();
                                if (manual || promptedCode != info.versionCode) {
                                    promptedCode = info.versionCode;
                                    askInstall(info);
                                }
                            }
                        }
                    });
                } catch (final Exception e) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            updateBusy = false;
                            updateLine = manual ? "Aggiornamenti: controllo non riuscito (" + e.getMessage() + ")" : "";
                            refresh();
                        }
                    });
                }
            }
        }, "s4me-update-check").start();
    }

    private void askInstall(final Updater.Info info) {
        new AlertDialog.Builder(this)
                .setTitle("Nuova versione " + info.versionName)
                .setMessage("Scaricare e installare l'aggiornamento di S4Me Assistant?")
                .setPositiveButton("Installa", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
                            // il permesso si chiede prima del download, poi si riparte da solo
                            waitingPermission = info;
                            Toast.makeText(MainActivity.this,
                                    "Consenti a S4Me Assistant di installare app, poi torna qui",
                                    Toast.LENGTH_LONG).show();
                            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                                    Uri.parse("package:" + getPackageName())));
                        } else {
                            downloadAndInstall(info);
                        }
                    }
                })
                .setNegativeButton("Dopo", null)
                .show();
    }

    private void downloadAndInstall(final Updater.Info info) {
        if (updateBusy) return;
        updateBusy = true;
        pendingInfo = info;
        updateLine = "Aggiornamenti: download 0%";
        refresh();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final File f = Updater.download(MainActivity.this, info, new Updater.Progress() {
                        @Override
                        public void percent(final int p) {
                            handler.post(new Runnable() {
                                @Override
                                public void run() {
                                    updateLine = "Aggiornamenti: download " + p + "%";
                                    refresh();
                                }
                            });
                        }
                    });
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            updateBusy = false;
                            pendingApk = f;
                            updateLine = "Aggiornamenti: pronto, conferma l'installazione";
                            refresh();
                            installPending();
                        }
                    });
                } catch (final Exception e) {
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            updateBusy = false;
                            updateLine = "Aggiornamenti: " + e.getMessage();
                            refresh();
                        }
                    });
                }
            }
        }, "s4me-update-download").start();
    }

    private void installPending() {
        if (pendingApk == null) return;
        boolean started = Updater.install(this, pendingApk);
        if (!started) {
            Toast.makeText(this, "Consenti a S4Me Assistant di installare app, poi torna qui",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void refreshLater() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                refresh();
            }
        }, 700);
    }

    private void refresh() {
        String ip = localIp();
        status.setText("Server: " + (AssistantService.running ? "ATTIVO" : "FERMO")
                + "\nIndirizzo: " + (ip.length() > 0
                ? "http://" + ip + ":" + AssistantService.PORT
                : "nessun Wi-Fi. Se Kodi e su questo telefono usa 127.0.0.1 porta "
                + AssistantService.PORT + ", altrimenti collegati al Wi-Fi")
                + "\nWebView: " + WebHolder.webViewVersion()
                + "\nBatteria: " + (batteryUnrestricted() ? "senza restrizioni"
                : "LIMITATA, premi BATTERIA e consenti")
                + "\nVersione: " + Updater.installedName(this)
                + (updateLine.length() > 0 ? "\n" + updateLine : "")
                + "\nTieni questa schermata aperta durante l'uso.");
    }

    private static String localIp() {
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (!a.isLoopbackAddress() && a instanceof Inet4Address
                            && a.isSiteLocalAddress()) {
                        return a.getHostAddress();
                    }
                }
            }
        } catch (Exception ignored) {
        }
        return "";
    }
}

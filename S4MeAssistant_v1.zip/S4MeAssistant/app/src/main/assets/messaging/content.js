var want = false;

function challenge() {
  try {
    var w = window.wrappedJSObject;
    if (typeof w._cf_chl_opt !== 'undefined') return true;
  } catch (e) {}
  return !!document.querySelector(
    '#challenge-form,#challenge-running,#challenge-stage,#cf-chl-widget,.cf-turnstile,#challenge-error-text');
}

function tick() {
  var msg = {
    type: 'page',
    href: location.href,
    title: document.title,
    ua: navigator.userAgent,
    chall: challenge(),
    html: want && document.documentElement ? document.documentElement.outerHTML : null
  };
  browser.runtime.sendMessage(msg).then(function (r) {
    want = !!(r && r.wantHtml);
  }, function () {});
}

setInterval(tick, 800);

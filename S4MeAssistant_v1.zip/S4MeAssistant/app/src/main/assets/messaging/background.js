browser.runtime.onMessage.addListener(async function (m) {
  if (!m || m.type !== 'page') return null;
  var cookies = [];
  try {
    cookies = await browser.cookies.getAll({ url: m.href });
  } catch (e) {}
  m.cookies = cookies.map(function (c) {
    return { name: c.name, value: c.value, domain: c.domain };
  });
  try {
    return await browser.runtime.sendNativeMessage('browser', m);
  } catch (e) {
    return null;
  }
});

# -*- coding: utf-8 -*-
# ------------------------------------------------------------------------------
# s4me_assistant: client per S4Me Assistant (stesso schema di Alfa Assistant).
# L'app gira sul telefono (o sullo stesso dispositivo) e risolve la challenge
# Cloudflare in una WebView. Questo modulo chiede la pagina all'app, salva i
# cookie ottenuti e li restituisce come header per le richieste successive.
# Da copiare in core/ dell'addon.
# ------------------------------------------------------------------------------

import base64
import json
import os
import sys
import time

try:
    from urllib.request import urlopen, Request
    from urllib.parse import quote, urlparse
except ImportError:
    from urllib2 import urlopen, Request
    from urllib import quote
    from urlparse import urlparse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

APP_ID = "com.s4me.assistant"
CF_COOKIE = "cf_clearance"
STORE_NAME = "s4me_cf_cookies.json"
DEFAULT_PORT = 8787
DEFAULT_APK_DIR = "/storage/emulated/0/Download/kodi_apk/"


# ------------------------------------------------------------------ impostazioni

def _addon():
    return xbmcaddon.Addon()


def _setting(key, default=""):
    try:
        value = _addon().getSetting(key)
    except Exception:
        value = ""
    return value if value not in (None, "") else default


def _int(key, default):
    try:
        return int(float(_setting(key, str(default))))
    except Exception:
        return default


def log(msg):
    xbmc.log("[S4Me Assistant] %s" % msg, getattr(xbmc, "LOGINFO", 1))


def notify(msg, error=False):
    icon = xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO
    xbmcgui.Dialog().notification("S4Me Assistant", msg, icon, 4000)


def is_enabled():
    return _setting("s4me_asst_enable", "false").lower() == "true"


def is_local():
    return _setting("s4me_asst_mode", "Remoto") == "Locale"


def base_url():
    host = "127.0.0.1" if is_local() else _setting("s4me_asst_ip")
    if not host:
        return ""
    return "http://%s:%d" % (host, _int("s4me_asst_port", DEFAULT_PORT))


# ------------------------------------------------------------------ rete

def _http_get(url, timeout):
    try:
        data = urlopen(Request(url), timeout=timeout).read()
        return data.decode("utf-8", "replace")
    except Exception as e:
        log("richiesta fallita: %s" % e)
        return None


def _b64q(text):
    """Base64 con caratteri sicuri per la query string."""
    return quote(base64.b64encode(text.encode("utf-8")).decode("ascii"), safe="")


def ping():
    base = base_url()
    if not base:
        return None
    raw = _http_get(base + "/ping", 3)
    if not raw:
        return None
    try:
        return json.loads(raw)
    except Exception:
        return None


def _is_android():
    return xbmc.getCondVisibility("system.platform.android")


def launch_local():
    if not _is_android():
        return False
    xbmc.executebuiltin(
        'StartAndroidActivity("%s","","open","about:blank")' % APP_ID)
    return True


def ensure_running(wait=15):
    if not base_url():
        notify("Imposta l'indirizzo dell'Assistant nelle impostazioni", True)
        return False
    if ping():
        return True
    if is_local():
        launch_local()
        for _ in range(wait):
            xbmc.sleep(1000)
            if ping():
                return True
    notify("Assistant non raggiungibile: apri l'app e tieni lo schermo acceso", True)
    return False


# ------------------------------------------------------------------ cookie salvati

def _store_path():
    profile = _addon().getAddonInfo("profile")
    try:
        profile = xbmcvfs.translatePath(profile)
    except AttributeError:
        profile = xbmc.translatePath(profile)
    if not os.path.isdir(profile):
        os.makedirs(profile)
    return os.path.join(profile, STORE_NAME)


def _load():
    try:
        with open(_store_path(), "r") as f:
            return json.load(f)
    except Exception:
        return {}


def _save_all(data):
    try:
        with open(_store_path(), "w") as f:
            json.dump(data, f, indent=1)
    except Exception as e:
        log("salvataggio cookie fallito: %s" % e)


def _key(url):
    return urlparse(url).netloc.lower()


def save_session(url, cookies, user_agent):
    data = _load()
    data[_key(url)] = {
        "cookies": cookies,
        "ua": user_agent,
        "saved": int(time.time()),
    }
    _save_all(data)


def get_session(url):
    """Sessione salvata e ancora valida per il dominio, altrimenti None."""
    data = _load()
    entry = data.get(_key(url))
    if not entry:
        return None
    ttl = _int("s4me_asst_ttl", 30) * 60
    if int(time.time()) - entry.get("saved", 0) > ttl or CF_COOKIE not in entry.get("cookies", {}):
        data.pop(_key(url), None)
        _save_all(data)
        return None
    return entry


def invalidate(url):
    data = _load()
    if data.pop(_key(url), None) is not None:
        _save_all(data)


def clear_all():
    _save_all({})
    base = base_url()
    if base and ping():
        _http_get(base + "/clearCookies", 5)
    notify("Cookie cancellati")


def headers_for(url):
    """Header (User-Agent e Cookie) da usare con la sessione salvata, o None."""
    entry = get_session(url)
    if not entry:
        return None
    cookie = "; ".join("%s=%s" % (k, v) for k, v in entry["cookies"].items())
    return {"User-Agent": entry["ua"], "Cookie": cookie}


# ------------------------------------------------------------------ bypass

def is_cloudflare(code, data):
    """Riconosce la pagina di challenge dalla risposta HTTP."""
    if code not in (403, 429, 503):
        return False
    low = (data or "")[:20000].lower()
    return "just a moment" in low or "cf-chl" in low or "cloudflare" in low


def solve(url, timeout=None):
    """Chiede all'Assistant di aprire la pagina. Ritorna un dict o None."""
    if not ensure_running():
        return None
    timeout = timeout or _int("s4me_asst_timeout", 40)
    parsed = urlparse(url)
    origin = "%s://%s" % (parsed.scheme, parsed.netloc)
    query = "url=%s&time=%d&returnWhenCookieNameFound=%s" % (
        _b64q(url), timeout * 1000, _b64q(origin + "|" + CF_COOKIE))
    raw = _http_get(base_url() + "/getSourceByPageFinished?" + query, timeout + 20)
    if not raw:
        return None
    try:
        data = json.loads(raw)
    except Exception:
        return None
    if data.get("error"):
        log("errore Assistant: %s" % data["error"])
        return None

    cookies = {}
    for c in data.get("cookies", []):
        cookies[c.get("name", "")] = c.get("value", "")
    sources = data.get("htmlSources") or [{}]
    html = sources[0].get("source", "")
    ua = data.get("userAgent", "")

    if cookies.get(CF_COOKIE):
        save_session(url, cookies, ua)
    return {"html": html, "cookies": cookies, "user_agent": ua,
            "solved": bool(data.get("solved"))}


def bypass(url, force=False):
    """
    Punto di ingresso per httptools.
    Ritorna {"headers": {...}, "html": str o None} oppure None.
    Con force=False usa la sessione salvata se ancora valida.
    """
    if not force:
        headers = headers_for(url)
        if headers:
            return {"headers": headers, "html": None}
    result = solve(url)
    if result and result["cookies"].get(CF_COOKIE):
        return {"headers": headers_for(url), "html": result["html"]}
    return None


# ------------------------------------------------------------------ APK

def download_apk():
    """Scarica l'APK dall'indirizzo impostato (o usa un percorso locale) e prova a installarlo."""
    src = _setting("s4me_asst_apk_url")
    dialog = xbmcgui.Dialog()
    if not src:
        dialog.ok("S4Me Assistant", "Imposta prima l'indirizzo del file APK.")
        return False

    if src.startswith("/"):
        path = src
    else:
        folder = _setting("s4me_asst_apk_dir", DEFAULT_APK_DIR)
        if not os.path.isdir(folder):
            try:
                os.makedirs(folder)
            except Exception:
                pass
        name = os.path.basename(urlparse(src).path) or "S4MeAssistant.apk"
        path = os.path.join(folder, name)
        progress = xbmcgui.DialogProgress()
        progress.create("S4Me Assistant", "Download in corso")
        try:
            resp = urlopen(Request(src, headers={"User-Agent": "Mozilla/5.0"}), timeout=30)
            total = int(resp.info().get("Content-Length") or 0)
            done = 0
            with open(path, "wb") as f:
                while True:
                    chunk = resp.read(65536)
                    if not chunk:
                        break
                    f.write(chunk)
                    done += len(chunk)
                    if total:
                        progress.update(int(done * 100 / total))
                    if progress.iscanceled():
                        raise Exception("annullato")
        except Exception as e:
            progress.close()
            dialog.ok("S4Me Assistant", "Download fallito:\n%s" % e)
            return False
        progress.close()

    if not os.path.isfile(path):
        dialog.ok("S4Me Assistant", "File non trovato:\n%s" % path)
        return False
    if _is_android():
        xbmc.executebuiltin(
            'StartAndroidActivity("","android.intent.action.VIEW",'
            '"application/vnd.android.package-archive","file://%s")' % path)
    dialog.ok("S4Me Assistant",
              "APK salvato in:\n%s\nSe l'installazione non parte, aprilo dal gestore file." % path)
    return True


def test_connection():
    info = ping()
    if info:
        xbmcgui.Dialog().ok(
            "S4Me Assistant",
            "Connesso.\nVersione app: %s\nWebView: %s" % (
                info.get("assistantVersion", "?"), info.get("wvbVersion", "?")))
    else:
        xbmcgui.Dialog().ok(
            "S4Me Assistant",
            "Nessuna risposta da %s\nControlla IP, porta e che l'app sia aperta." % (
                base_url() or "(indirizzo non impostato)"))


if __name__ == "__main__":
    action = sys.argv[1] if len(sys.argv) > 1 else ""
    if action == "apk":
        download_apk()
    elif action == "ping":
        test_connection()
    elif action == "clear":
        clear_all()

package com.s4me.assistant;

import android.content.Context;

import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;

/** Socket del server con TLS 1.2 e 1.3, certificato EC incluso nell'app (versione di prova). */
final class TlsFactory {
    private static final char[] PASS = "s4me-tls".toCharArray();

    private TlsFactory() {
    }

    static ServerSocket create(Context c) throws IOException {
        try {
            KeyStore ks = KeyStore.getInstance("PKCS12");
            InputStream in = c.getResources().openRawResource(R.raw.s4me_tls);
            try {
                ks.load(in, PASS);
            } finally {
                in.close();
            }
            KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            kmf.init(ks, PASS);
            SSLContext ctx = SSLContext.getInstance("TLS");
            ctx.init(kmf.getKeyManagers(), null, null);
            SSLServerSocket s = (SSLServerSocket) ctx.getServerSocketFactory().createServerSocket();
            List<String> ok = new ArrayList<String>();
            for (String p : s.getSupportedProtocols()) {
                if (p.equals("TLSv1.2") || p.equals("TLSv1.3")) ok.add(p);
            }
            s.setEnabledProtocols(ok.toArray(new String[0]));
            return s;
        } catch (IOException e) {
            throw e;
        } catch (Exception e) {
            throw new IOException("TLS: " + e);
        }
    }
}

package com.s4me.assistant;

import android.app.Activity;
import android.content.Context;
import android.content.MutableContextWrapper;
import android.content.pm.PackageInfo;
import android.graphics.Bitmap;
import android.os.Build;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.ProxyConfig;
import androidx.webkit.ProxyController;
import androidx.webkit.WebViewFeature;

/**
 * Tiene una sola WebView per tutta l'app. Quando l'Activity e' visibile la
 * WebView viene agganciata allo schermo, cosi la challenge Cloudflare e'
 * visibile e si puo toccare (Turnstile). Quando l'Activity e' chiusa la
 * WebView resta viva ma staccata.
 */
public class WebHolder {
    private static WebView webView;
    private static MutableContextWrapper wrapper;

    public static volatile int finishedCount = 0;
    public static volatile String currentUrl = "";
    public static volatile String defaultUserAgent = "";

    public static volatile boolean ipv4Only = false;

    /** Fa passare tutto il traffico della WebView dal proxy locale che usa solo IPv4. */
    private static void forceIpv4() {
        try {
            if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) return;
            if (!Ipv4Proxy.start()) return;
            ProxyConfig cfg = new ProxyConfig.Builder()
                    .addProxyRule("127.0.0.1:" + Ipv4Proxy.port())
                    .build();
            ProxyController.getInstance().setProxyOverride(cfg, new java.util.concurrent.Executor() {
                @Override
                public void execute(Runnable r) {
                    r.run();
                }
            }, new Runnable() {
                @Override
                public void run() {
                    ipv4Only = true;
                }
            });
        } catch (Throwable t) {
            android.util.Log.e("S4MeWeb", "proxy IPv4: " + t);
        }
    }

    public static synchronized WebView get(Context ctx) {
        if (webView == null) {
            forceIpv4();
            wrapper = new MutableContextWrapper(ctx.getApplicationContext());
            webView = new WebView(wrapper);

            WebSettings s = webView.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setLoadsImagesAutomatically(true);
            s.setJavaScriptCanOpenWindowsAutomatically(false);
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
            s.setMediaPlaybackRequiresUserGesture(true);
            defaultUserAgent = s.getUserAgentString();

            CookieManager cm = CookieManager.getInstance();
            cm.setAcceptCookie(true);
            cm.setAcceptThirdPartyCookies(webView, true);

            webView.setWebViewClient(new WebViewClient() {
                /** Solo http e https: link come tg:, intent: o market: farebbero comparire "pagina non disponibile". */
                private boolean isWeb(String url) {
                    if (url == null) return true;
                    String u = url.trim().toLowerCase();
                    return u.startsWith("http://") || u.startsWith("https://")
                            || u.startsWith("about:") || u.startsWith("data:")
                            || u.startsWith("blob:") || u.startsWith("javascript:");
                }

                @Override
                public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                    return !isWeb(request.getUrl().toString());
                }

                @Override
                public boolean shouldOverrideUrlLoading(WebView v, String url) {
                    return !isWeb(url);
                }

                @Override
                public void onPageStarted(WebView v, String url, Bitmap favicon) {
                    currentUrl = url;
                }

                @Override
                public void onPageFinished(WebView v, String url) {
                    currentUrl = url;
                    finishedCount = finishedCount + 1;
                }
            });
            webView.onResume();
        }
        return webView;
    }

    public static synchronized void attach(Activity activity, ViewGroup container) {
        get(activity);
        wrapper.setBaseContext(activity);
        detachFromParent();
        container.addView(webView, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));
    }

    public static synchronized void detach(Context app) {
        if (webView == null) return;
        detachFromParent();
        wrapper.setBaseContext(app.getApplicationContext());
    }

    private static void detachFromParent() {
        if (webView != null && webView.getParent() instanceof ViewGroup) {
            ((ViewGroup) webView.getParent()).removeView(webView);
        }
    }

    public static String webViewVersion() {
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                PackageInfo pi = WebView.getCurrentWebViewPackage();
                if (pi != null && pi.versionName != null) return pi.versionName;
            }
        } catch (Throwable ignored) {
        }
        return "";
    }
}

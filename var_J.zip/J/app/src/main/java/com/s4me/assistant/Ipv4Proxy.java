package com.s4me.assistant;

import android.util.Log;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Proxy locale che apre tutte le connessioni in uscita solo in IPv4.
 * La WebView passa da qui, cosi il cookie cf_clearance viene emesso per lo
 * stesso indirizzo IPv4 pubblico che userano poi Kodi e gli altri dispositivi
 * di casa. Il traffico HTTPS resta cifrato end to end (tunnel CONNECT), quindi
 * l'impronta TLS e' sempre quella della WebView.
 */
public class Ipv4Proxy {
    private static final String TAG = "S4MeProxy";
    private static volatile int port = 0;
    private static ServerSocket server;
    private static final ExecutorService POOL = Executors.newCachedThreadPool();

    public static int port() {
        return port;
    }

    public static synchronized boolean start() {
        if (server != null) return true;
        try {
            server = new ServerSocket(0, 50, InetAddress.getByName("127.0.0.1"));
            port = server.getLocalPort();
        } catch (IOException e) {
            Log.e(TAG, "avvio: " + e);
            server = null;
            return false;
        }
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                while (true) {
                    try {
                        final Socket c = server.accept();
                        POOL.execute(new Runnable() {
                            @Override
                            public void run() {
                                handle(c);
                            }
                        });
                    } catch (Exception e) {
                        Log.e(TAG, "accept: " + e);
                        return;
                    }
                }
            }
        }, "s4me-ipv4-proxy");
        t.setDaemon(true);
        t.start();
        return true;
    }

    private static Socket connect(String host, int p) throws IOException {
        InetAddress[] all = InetAddress.getAllByName(host);
        InetAddress pick = null;
        for (InetAddress a : all) {
            if (a instanceof Inet4Address) {
                pick = a;
                break;
            }
        }
        if (pick == null) pick = all[0];
        Socket s = new Socket();
        s.connect(new InetSocketAddress(pick, p), 15000);
        s.setTcpNoDelay(true);
        return s;
    }

    /** Legge fino alla riga vuota che chiude le intestazioni. */
    private static byte[] readHead(InputStream in) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        int state = 0;
        int b;
        while ((b = in.read()) != -1) {
            bo.write(b);
            if (b == '\r' && (state == 0 || state == 2)) state++;
            else if (b == '\n' && (state == 1 || state == 3)) state++;
            else state = (b == '\r') ? 1 : 0;
            if (state == 4) break;
            if (bo.size() > 65536) throw new IOException("intestazioni troppo lunghe");
        }
        return bo.toByteArray();
    }

    private static void handle(Socket c) {
        Socket up = null;
        try {
            c.setSoTimeout(0);
            InputStream cin = c.getInputStream();
            OutputStream cout = c.getOutputStream();
            byte[] head = readHead(cin);
            if (head.length == 0) return;
            String text = new String(head, "ISO-8859-1");
            int eol = text.indexOf("\r\n");
            String first = eol > 0 ? text.substring(0, eol) : text;
            String[] parts = first.split(" ");
            if (parts.length < 3) return;

            if (parts[0].equalsIgnoreCase("CONNECT")) {
                String hp = parts[1];
                int i = hp.lastIndexOf(':');
                String host = i > 0 ? hp.substring(0, i) : hp;
                int p = i > 0 ? Integer.parseInt(hp.substring(i + 1)) : 443;
                if (host.startsWith("[") && host.endsWith("]")) host = host.substring(1, host.length() - 1);
                up = connect(host, p);
                cout.write("HTTP/1.1 200 Connection Established\r\n\r\n".getBytes("ISO-8859-1"));
                cout.flush();
            } else {
                String url = parts[1];
                if (!url.toLowerCase().startsWith("http://")) return;
                String rest = url.substring(7);
                int slash = rest.indexOf('/');
                String hp = slash >= 0 ? rest.substring(0, slash) : rest;
                String path = slash >= 0 ? rest.substring(slash) : "/";
                int i = hp.lastIndexOf(':');
                String host = i > 0 ? hp.substring(0, i) : hp;
                int p = i > 0 ? Integer.parseInt(hp.substring(i + 1)) : 80;
                up = connect(host, p);
                String newFirst = parts[0] + " " + path + " " + parts[2];
                String newHead = newFirst + text.substring(eol).replaceAll("(?im)^Proxy-Connection:.*\r\n", "");
                up.getOutputStream().write(newHead.getBytes("ISO-8859-1"));
                up.getOutputStream().flush();
            }
            pipe(c, up);
        } catch (Exception e) {
            Log.w(TAG, "connessione: " + e);
        } finally {
            close(up);
            close(c);
        }
    }

    private static void pipe(final Socket a, final Socket b) throws IOException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                copy(b, a);
            }
        }, "s4me-pipe");
        t.setDaemon(true);
        t.start();
        copy(a, b);
        try {
            t.join(2000);
        } catch (InterruptedException ignored) {
        }
    }

    private static void copy(Socket from, Socket to) {
        byte[] buf = new byte[16384];
        try {
            InputStream in = from.getInputStream();
            OutputStream out = to.getOutputStream();
            int n;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
                out.flush();
            }
            try {
                to.shutdownOutput();
            } catch (Exception ignored) {
            }
        } catch (IOException ignored) {
            close(from);
            close(to);
        }
    }

    private static void close(Socket s) {
        try {
            if (s != null) s.close();
        } catch (IOException ignored) {
        }
    }
}
